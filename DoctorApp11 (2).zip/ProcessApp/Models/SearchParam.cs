﻿namespace ProcessApp.Models
{
    public class SearchParam
    {
        public string Date { get; set; }
        public string Name { get; set; }
        public string Medicine { get; set; }
    }
}
